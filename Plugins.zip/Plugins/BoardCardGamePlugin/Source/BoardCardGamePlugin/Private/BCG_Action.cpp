// Fill out your copyright notice in the Description page of Project Settings.


#include "BCG_Action.h"
#include "BCG_Dealer.h"
#include "BCG_Player.h"

//void UBCG_Action::Execute_Implementation(ABCG_Player* player, ABCG_Dealer* dealer)
//{
//	Dealer = dealer;
//	BCG_FinnishAction.AddDynamic(dealer, &ABCG_Dealer::TurnNextPlayer);
//	BCG_FinnishAction.AddDynamic(this, &UBCG_Action::BCG_RemoveAction);
//}

UBCG_Action::UBCG_Action()
{
	//Cast<ABCG_Player>(GetOuter());
	BCG_FinnishAction.AddDynamic(this, &UBCG_Action::BCG_RemoveAction);
}

void UBCG_Action::BCG_RemoveAction(bool success)
{
	if (!success) return;

	BCG_FinnishAction.RemoveAll(this);
}
